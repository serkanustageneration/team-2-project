import logging
import boto3
import pandas as pd
import urllib.parse

LOGGER = logging.getLogger()
LOGGER.setLevel(logging.INFO)

# Use boto3 to download the event s3 object key to the /tmp directory.
s3 = boto3.resource('s3')
marshall = 'marshall-bucket-generation'

my_bucket = s3.Bucket(marshall)
for file in my_bucket.objects.all():
    print(f"Bucket:{marshall}, Key: {file.key}")

def handler(event, context):
    LOGGER.info(f'Event structure: {event}')
    
    bucket = event['Records'][0]['s3']['bucket']['name']
    key = urllib.parse.unquote_plus(
        event['Records'][0]['s3']['object']['key'], encoding='utf-8')
    try:
        response = s3.get_object(Bucket=bucket, Key=key)
        print("CONTENT TYPE: " + response['ContentType'])
        return response['ContentType']
    except Exception as e:
        print(e)
        print('Error getting object {} from bucket P{. Make sure they exist and your bucket is in the same')
        raise e
    

# for bucket in s3.buckets.all():    
#     my_bucket = s3.Bucket(bucket.name)
    
#     for file in my_bucket.objects.all():
#         print(f"Bucket:{bucket.name} Key: {file.key}")
    # Use pandas to read the csv.

    # Log the dataframe head.